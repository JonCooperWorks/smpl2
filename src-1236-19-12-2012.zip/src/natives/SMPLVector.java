/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package natives;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author jean-paul
 */
public class SMPLVector {
    static ArrayList<SMPLContainer> NIL = new ArrayList();
    ArrayList<SMPLContainer> values;
    
    public SMPLVector(){
        values = new ArrayList();
    }
    
    public SMPLVector(SMPLContainer... param){
        values = new ArrayList(Arrays.asList(param));
    }
    
    public SMPLVector(ArrayList<SMPLContainer> param){
        values = new ArrayList(param);
    }
    
    public SMPLVector(SMPLVector param){
        values = new ArrayList(param.values);
    }

    public ArrayList<SMPLContainer> getValues() {
        return values;
    }
    
}
