/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package smpl;

import astreps.ASTBitAndExp;
import astreps.ASTBitNotExp;
import astreps.ASTBitOrExp;
import astreps.ASTBoAndExp;
import astreps.ASTBoNotExp;
import astreps.ASTBoOrExp;
import astreps.ASTBooleanExp;
import astreps.ASTDefine;
import astreps.ASTFloatExp;
import astreps.ASTFunCallExp;
import astreps.ASTFunDefExp;
import astreps.ASTIdExp;
import astreps.ASTIntExp;
import astreps.ASTNmAddExp;
import astreps.ASTNmDivExp;
import astreps.ASTNmEqlExp;
import astreps.ASTNmGEqlExp;
import astreps.ASTNmGrtrExp;
import astreps.ASTNmLEqlExp;
import astreps.ASTNmLessExp;
import astreps.ASTNmModExp;
import astreps.ASTNmMulExp;
import astreps.ASTNmNotEqlExp;
import astreps.ASTNmSubExp;
import astreps.ASTNode;
import astreps.ASTSequence;
import astreps.ASTStringExp;
import astreps.ASTVectorExp;
import astreps.SMPLProgram;
import java.util.ArrayList;
import natives.SMPLBoolean;
import natives.SMPLContainer;
import natives.SMPLFloat;
import natives.SMPLFunction;
import natives.SMPLInt;
import natives.SMPLString;
import natives.SMPLVector;

/**
 *
 * @author jean-paul
 */
public class SMPLVisitor implements Visitor<SMPLEnvironment, SMPLContainer> {

    @Override
    public void setup() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public SMPLEnvironment createInitialState() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void output(SMPLContainer value) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public SMPLContainer visitProgram(SMPLProgram prog, SMPLEnvironment state) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public SMPLContainer visitSequence(ASTSequence seq, SMPLEnvironment state) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    @Override
    public SMPLContainer visitDefine(ASTDefine def, SMPLEnvironment state) {
        SMPLContainer contents = def.getContents().visit(this, state);
        String key = def.getID();
        state.put(key, contents);
        return contents;
    }

    @Override
    public SMPLContainer visitID(ASTIdExp id, SMPLEnvironment state) {
        return state.get( id.getName() );
    }

    @Override
    public SMPLContainer visitMakeBoolean(ASTBooleanExp bool, SMPLEnvironment state) {
        return new SMPLContainer( new SMPLBoolean( bool.getValue() ) );
    }

    @Override
    public SMPLContainer visitMakeFloat(ASTFloatExp flVal, SMPLEnvironment state) {
        return new SMPLContainer( new SMPLFloat( flVal.getValue() ) );
    }

    @Override
    public SMPLContainer visitMakeInt(ASTIntExp intVal, SMPLEnvironment state) {
        return new SMPLContainer( new SMPLInt( intVal.getValue() ) );
    }

    @Override
    public SMPLContainer visitMakeString(ASTStringExp str, SMPLEnvironment state) {
        return new SMPLContainer( new SMPLString( str.getValue() ) );
    }

    @Override
    public SMPLContainer visitMakeVector(ASTVectorExp vec, SMPLEnvironment state) {
        ArrayList<ASTNode> contents = vec.getValue();
        ArrayList<SMPLContainer> container = new ArrayList<SMPLContainer>();
        for (int i = 0; i < contents.size(); i++){
            ASTNode curr = contents.get(i);
            container.add( curr.visit(this, state) );
        }
        return new SMPLContainer( new SMPLVector(container) );
    }

    @Override
    public SMPLContainer visitBoolNot(ASTBoNotExp bnot, SMPLEnvironment state) {
        boolean bexp = ((SMPLBoolean) bnot.getOper().visit(this, state).getValue()).isValue();
        return new SMPLContainer ( new SMPLBoolean( !bexp ) );
    }

    @Override
    public SMPLContainer visitBoolAnd(ASTBoAndExp band, SMPLEnvironment state) {
        boolean bexp1 = ((SMPLBoolean) band.getOper().visit(this, state).getValue()).isValue();
        boolean bexp2 = ((SMPLBoolean) band.getOper2().visit(this, state).getValue()).isValue();
        return new SMPLContainer ( new SMPLBoolean( bexp1 && bexp2 ) );
    }

    @Override
    public SMPLContainer visitBoolOr(ASTBoOrExp bor, SMPLEnvironment state) {
        boolean bexp1 = ((SMPLBoolean) bor.getOper().visit(this, state).getValue()).isValue();
        boolean bexp2 = ((SMPLBoolean) bor.getOper2().visit(this, state).getValue()).isValue();
        return new SMPLContainer ( new SMPLBoolean( bexp1 || bexp2 ) );
    }

    @Override
    public SMPLContainer visitNmAdd(ASTNmAddExp nmadd, SMPLEnvironment state) {
        SMPLContainer container;
        int check1 = nmadd.getOper().visit(this, state).getType().compareTo("Float");
        int check2 = nmadd.getOper2().visit(this, state).getType().compareTo("Float");
        if ( check1 == 0 || check2 == 0){
            double oper1 = ((SMPLFloat) nmadd.getOper().visit(this, state).getValue()).getValue();
            double oper2 = ((SMPLFloat) nmadd.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLFloat( oper1 + oper2 ) );
        }
        else {
            int oper1 = ((SMPLInt) nmadd.getOper().visit(this, state).getValue()).getValue();
            int oper2 = ((SMPLInt) nmadd.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLInt( oper1 + oper2 ) );
        }
        return container;
    }

    @Override
    public SMPLContainer visitNmSub(ASTNmSubExp nmsub, SMPLEnvironment state) {
        SMPLContainer container;
        int check1 = nmsub.getOper().visit(this, state).getType().compareTo("Float");
        int check2 = nmsub.getOper2().visit(this, state).getType().compareTo("Float");
        if ( check1 == 0 || check2 == 0){
            double oper1 = ((SMPLFloat) nmsub.getOper().visit(this, state).getValue()).getValue();
            double oper2 = ((SMPLFloat) nmsub.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLFloat( oper1 - oper2 ) );
        }
        else {
            int oper1 = ((SMPLInt) nmsub.getOper().visit(this, state).getValue()).getValue();
            int oper2 = ((SMPLInt) nmsub.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLInt( oper1 - oper2 ) );
        }
        return container;
    }

    @Override
    public SMPLContainer visitNmMul(ASTNmMulExp nmmul, SMPLEnvironment state) {
        SMPLContainer container;
        int check1 = nmmul.getOper().visit(this, state).getType().compareTo("Float");
        int check2 = nmmul.getOper2().visit(this, state).getType().compareTo("Float");
        if ( check1 == 0 || check2 == 0){
            double oper1 = ((SMPLFloat) nmmul.getOper().visit(this, state).getValue()).getValue();
            double oper2 = ((SMPLFloat) nmmul.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLFloat( oper1 * oper2 ) );
        }
        else {
            int oper1 = ((SMPLInt) nmmul.getOper().visit(this, state).getValue()).getValue();
            int oper2 = ((SMPLInt) nmmul.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLInt( oper1 * oper2 ) );
        }
        return container;
    }

    @Override
    public SMPLContainer visitNmDiv(ASTNmDivExp nmdiv, SMPLEnvironment state) {
        SMPLContainer container;
        int check1 = nmdiv.getOper().visit(this, state).getType().compareTo("Float");
        int check2 = nmdiv.getOper2().visit(this, state).getType().compareTo("Float");
        if ( check1 == 0 || check2 == 0){
            double oper1 = ((SMPLFloat) nmdiv.getOper().visit(this, state).getValue()).getValue();
            double oper2 = ((SMPLFloat) nmdiv.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLFloat( oper1 / oper2 ) );
        }
        else {
            int oper1 = ((SMPLInt) nmdiv.getOper().visit(this, state).getValue()).getValue();
            int oper2 = ((SMPLInt) nmdiv.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLInt( oper1 / oper2 ) );
        }
        return container;
    }

    @Override
    public SMPLContainer visitNmMod(ASTNmModExp nmmod, SMPLEnvironment state) {
        SMPLContainer container;
        int check1 = nmmod.getOper().visit(this, state).getType().compareTo("Float");
        int check2 = nmmod.getOper2().visit(this, state).getType().compareTo("Float");
        if ( check1 == 0 || check2 == 0){
            double oper1 = ((SMPLFloat) nmmod.getOper().visit(this, state).getValue()).getValue();
            double oper2 = ((SMPLFloat) nmmod.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLFloat( oper1 % oper2 ) );
        }
        else {
            int oper1 = ((SMPLInt) nmmod.getOper().visit(this, state).getValue()).getValue();
            int oper2 = ((SMPLInt) nmmod.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLInt( oper1 % oper2 ) );
        }
        return container;
    }

    @Override
    public SMPLContainer visitNmEquals(ASTNmEqlExp nmeqls, SMPLEnvironment state) {
        SMPLContainer container;
        int check1 = nmeqls.getOper().visit(this, state).getType().compareTo("Float");
        int check2 = nmeqls.getOper2().visit(this, state).getType().compareTo("Float");
        if ( check1 == 0 || check2 == 0){
            double oper1 = ((SMPLFloat) nmeqls.getOper().visit(this, state).getValue()).getValue();
            double oper2 = ((SMPLFloat) nmeqls.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLBoolean( oper1 == oper2 ) );
        }
        else {
            int oper1 = ((SMPLInt) nmeqls.getOper().visit(this, state).getValue()).getValue();
            int oper2 = ((SMPLInt) nmeqls.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLBoolean( oper1 == oper2 ) );
        }
        return container;
    }

    @Override
    public SMPLContainer visitNmLThan(ASTNmLessExp nmless, SMPLEnvironment state) {
        SMPLContainer container;
        int check1 = nmless.getOper().visit(this, state).getType().compareTo("Float");
        int check2 = nmless.getOper2().visit(this, state).getType().compareTo("Float");
        if ( check1 == 0 || check2 == 0){
            double oper1 = ((SMPLFloat) nmless.getOper().visit(this, state).getValue()).getValue();
            double oper2 = ((SMPLFloat) nmless.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLBoolean( oper1 < oper2 ) );
        }
        else {
            int oper1 = ((SMPLInt) nmless.getOper().visit(this, state).getValue()).getValue();
            int oper2 = ((SMPLInt) nmless.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLBoolean( oper1 < oper2 ) );
        }
        return container;
    }

    @Override
    public SMPLContainer visitNmGThan(ASTNmGrtrExp nmgrtr, SMPLEnvironment state) {
        SMPLContainer container;
        int check1 = nmgrtr.getOper().visit(this, state).getType().compareTo("Float");
        int check2 = nmgrtr.getOper2().visit(this, state).getType().compareTo("Float");
        if ( check1 == 0 || check2 == 0){
            double oper1 = ((SMPLFloat) nmgrtr.getOper().visit(this, state).getValue()).getValue();
            double oper2 = ((SMPLFloat) nmgrtr.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLBoolean( oper1 > oper2 ) );
        }
        else {
            int oper1 = ((SMPLInt) nmgrtr.getOper().visit(this, state).getValue()).getValue();
            int oper2 = ((SMPLInt) nmgrtr.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLBoolean( oper1 > oper2 ) );
        }
        return container;
    }

    @Override
    public SMPLContainer visitNmLEqls(ASTNmLEqlExp nmleql, SMPLEnvironment state) {
        SMPLContainer container;
        int check1 = nmleql.getOper().visit(this, state).getType().compareTo("Float");
        int check2 = nmleql.getOper2().visit(this, state).getType().compareTo("Float");
        if ( check1 == 0 || check2 == 0){
            double oper1 = ((SMPLFloat) nmleql.getOper().visit(this, state).getValue()).getValue();
            double oper2 = ((SMPLFloat) nmleql.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLBoolean( oper1 <= oper2 ) );
        }
        else {
            int oper1 = ((SMPLInt) nmleql.getOper().visit(this, state).getValue()).getValue();
            int oper2 = ((SMPLInt) nmleql.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLBoolean( oper1 <= oper2 ) );
        }
        return container;
    }

    @Override
    public SMPLContainer visitNmGEqls(ASTNmGEqlExp nmgeql, SMPLEnvironment state) {
        SMPLContainer container;
        int check1 = nmgeql.getOper().visit(this, state).getType().compareTo("Float");
        int check2 = nmgeql.getOper2().visit(this, state).getType().compareTo("Float");
        if ( check1 == 0 || check2 == 0){
            double oper1 = ((SMPLFloat) nmgeql.getOper().visit(this, state).getValue()).getValue();
            double oper2 = ((SMPLFloat) nmgeql.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLBoolean( oper1 >= oper2 ) );
        }
        else {
            int oper1 = ((SMPLInt) nmgeql.getOper().visit(this, state).getValue()).getValue();
            int oper2 = ((SMPLInt) nmgeql.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLBoolean( oper1 >= oper2 ) );
        }
        return container;
    }

    @Override
    public SMPLContainer visitNmNotEql(ASTNmNotEqlExp nmneql, SMPLEnvironment state) {
        SMPLContainer container;
        int check1 = nmneql.getOper().visit(this, state).getType().compareTo("Float");
        int check2 = nmneql.getOper2().visit(this, state).getType().compareTo("Float");
        if ( check1 == 0 || check2 == 0){
            double oper1 = ((SMPLFloat) nmneql.getOper().visit(this, state).getValue()).getValue();
            double oper2 = ((SMPLFloat) nmneql.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLBoolean( oper1 != oper2 ) );
        }
        else {
            int oper1 = ((SMPLInt) nmneql.getOper().visit(this, state).getValue()).getValue();
            int oper2 = ((SMPLInt) nmneql.getOper2().visit(this, state).getValue()).getValue();
            container = new SMPLContainer( new SMPLBoolean( oper1 != oper2 ) );
        }
        return container;
    }

    @Override
    public SMPLContainer visitBitAnd(ASTBitAndExp btand, SMPLEnvironment state) {
        int oper1 = ((SMPLInt) btand.getOper().visit(this, state).getValue()).getValue();
        int oper2 = ((SMPLInt) btand.getOper2().visit(this, state).getValue()).getValue();
        return new SMPLContainer( new SMPLInt( oper1 & oper2 ) );
    }

    @Override
    public SMPLContainer visitBitOr(ASTBitOrExp btand, SMPLEnvironment state) {
        int oper1 = ((SMPLInt) btand.getOper().visit(this, state).getValue()).getValue();
        int oper2 = ((SMPLInt) btand.getOper2().visit(this, state).getValue()).getValue();
        return new SMPLContainer( new SMPLInt( oper1 | oper2 ) );
    }

    @Override
    public SMPLContainer visitBitNot(ASTBitNotExp btand, SMPLEnvironment state) {
        int oper = ((SMPLInt) btand.getOper().visit(this, state).getValue()).getValue();
        return new SMPLContainer( new SMPLInt( ~oper ) );
    }

    @Override
    public SMPLContainer visitFunDef(ASTFunDefExp fundef, SMPLEnvironment state) {
        String key = fundef.getName();
        ASTNode body = fundef.getBody();
        ArrayList<String> params = fundef.getParameters();
        SMPLContainer contents = new SMPLContainer( new SMPLFunction( key, params, body ) );
        state.put(key, contents);
        return contents;
    }

    @Override
    public SMPLContainer visitFunCall(ASTFunCallExp funcall, SMPLEnvironment state) {
        SMPLEnvironment child = new SMPLEnvironment(state);
        SMPLFunction funcToCall = (SMPLFunction) state.get( funcall.getName() ).getValue();
        
        // Put all the arguments into the child environment.
        for (int i = 0; i < funcToCall.getParams().size(); i++){
            child.put(funcToCall.getParam(i), funcall.getArg(i).visit(this, state) );
        }
        
        return funcToCall.getBody().visit(this, child);
    }
    
}
