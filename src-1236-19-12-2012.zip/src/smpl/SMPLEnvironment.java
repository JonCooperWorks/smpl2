/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package smpl;

import java.util.HashMap;
import natives.SMPLContainer;

/**
 *
 * @author jean-paul
 */
public class SMPLEnvironment {
    private HashMap<String, SMPLContainer> env;
    private SMPLEnvironment parent;
    
    // Creates environ as global.
    public SMPLEnvironment(){
        env = new HashMap<String, SMPLContainer>();
        parent = null;
    }
    
    public SMPLEnvironment(SMPLEnvironment mother){
        env = new HashMap<String, SMPLContainer>();
        parent = mother;
    }
    
    public void put(String id, SMPLContainer item){
        env.put(id, item);
    }
    
    public SMPLContainer get(String id){
        SMPLContainer target = env.get(id);
        if (target == null){
            parent.get(id);
        }
        return target;
    }
}
