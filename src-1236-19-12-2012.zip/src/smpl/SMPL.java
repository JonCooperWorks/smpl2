/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package smpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

/**
 *
 * @author jean-paul
 */
public class SMPL {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SMPLEnvironment environment = new SMPLEnvironment();
        SMPLVisitor visitor = new SMPLVisitor();
        
        for (int i = 0; i < args.length; i++){
            try {
                if ( args[i].startsWith("-file")){
                    parseEvalShow(new FileInputStream( new File(args[i].substring(7)) ), visitor, environment);
                }
                else {
                    parseEvalShow(System.in, visitor, environment);
                }
            }
            catch (FileNotFoundException fe){
                System.out.println("Could not find file " + args[i].substring(7));
            }
        }
    }
    
    private static <S, T> void parseEvalShow(InputStream stream, Visitor<S, T> visitor, S state){
//        SMPLLexer lexer;
//        SMPLParser parser;
//        SMPLProgram commands = null;
//
//        //System.out.print(PROMPT);
//        try {
//            lexer = new SMPLLexer(stream);
//            parser = new SMPLParser(lexer);
//            commands = (SMPLProgram) parser.parse().value;
//        } catch (Exception e) {
//            System.out.println("Syntax Error: " + e.getMessage());
//        }
//
//        T result;
//        if (commands != null) {
//            try {
//                result = commands.visit(visitor, state);
//                visitor.output(result);
//                if (result != null) {
//                    // Display value returned.
//                } else {
//                    System.out.println("\nNo result");
//                }
//            } catch (NullPointerException e) {
//                System.out.println("Runtime Error: " + e.getMessage());
//            }
//        }
    }
}
