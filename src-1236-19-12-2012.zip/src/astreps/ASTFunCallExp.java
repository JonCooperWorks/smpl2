/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package astreps;

import java.util.ArrayList;
import smpl.Visitor;

/**
 *
 * @author jean-paul
 */
public class ASTFunCallExp extends ASTNode{
    
    ArrayList<ASTNode> arguments;
    
    public ASTFunCallExp(String nm, ArrayList<ASTNode> args){
        super(nm);
        arguments = args;
    }
    
    public ASTNode getArg(int i){
        return arguments.get(i);
    }

    @Override
    public <S, T> T visit(Visitor<S, T> visitor, S state) {
        return visitor.visitFunCall(this, state);
    }
    
}
