/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package astreps;

import java.util.ArrayList;
import smpl.Visitor;

/**
 *
 * @author jean-paul
 */
public class ASTFunDefExp extends ASTNode{

    ArrayList<String> parameters;
    ASTNode body;
    
    public ASTFunDefExp(String nm, ArrayList<String> param, ASTNode contents){
        super(nm);
        this.parameters = param;
        this.body = contents;
    }

    public ArrayList<String> getParameters() {
        return parameters;
    }

    public ASTNode getBody() {
        return body;
    }
    
    @Override
    public <S, T> T visit(Visitor<S, T> visitor, S state) {
        return visitor.visitFunDef(this, state);
    }
    
}
