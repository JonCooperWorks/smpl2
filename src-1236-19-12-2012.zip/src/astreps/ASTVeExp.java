/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package astreps;

import java.util.ArrayList;

/**
 *
 * @author jean-paul
 */
public abstract class ASTVeExp extends ASTNode{

    public ASTVeExp() {
    }

    public ASTVeExp(String nm) {
        super(nm);
    }

    public ASTVeExp(String nm, ASTNode... c) {
        super(nm, c);
    }

    public ASTVeExp(String nm, ArrayList<ASTNode> c) {
        super(nm, c);
    }
    
}
